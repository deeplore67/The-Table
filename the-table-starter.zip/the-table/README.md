# The Table

A dark, pseudonymous, invite-only chat website starter.

## Important

The included JavaScript is intentionally a **demo**. It does not provide real
private chat or secure invitation verification.

For a real deployment:

1. Put the frontend on GitHub Pages.
2. Create a Supabase project.
3. Create tables for invitations, profiles/usernames, rooms and messages.
4. Enable Row Level Security (RLS).
5. Verify invitation tokens on the backend/server side.
6. Never put a Supabase service-role key in `app.js`.
7. Use HTTPS and reasonable message/rate limits.
8. Add reporting and moderation controls.

The anonymous username should be treated as **pseudonymous**, not guaranteed
anonymous. A website operator or backend can still potentially see technical
information such as IP addresses depending on the services used.

## GitHub Pages

Create a repository, upload `index.html`, `style.css`, `app.js`, and this README,
then enable GitHub Pages for the repository's main branch.

## Suggested database design

### invitations
- id
- token_hash
- active
- expires_at
- max_uses
- uses

### profiles
- id
- username
- created_at

### messages
- id
- profile_id
- room_id
- body
- created_at
- deleted_at

Use server-side authorization/RLS so a visitor cannot bypass the invitation
system by changing browser JavaScript.
